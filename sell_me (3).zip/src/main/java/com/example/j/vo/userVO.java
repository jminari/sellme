package com.example.j.vo;

import lombok.Data;
@Data
public class userVO {
    private String userId;
    private String userPw;
    private String userName;
    private String userEmail;
    private String userPhNum;
    private String userBirth;
    private String userGender;
    private String userAddress;
    private String userPurpose;
    private String userCity;
}
