package com.example.j.vo;

import lombok.Data;

@Data
public class graduationVO {
    private String userId;
    private int num;
    private String gradDate;
    private String gradName;
    private String gradType;
}